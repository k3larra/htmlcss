# Description tag

Som du ser får man ett antal träffar på Wikipedia, en av dessa bör vara den engelskpråkiga sidan med addresen https://www.wikipedia.org/ där descriptiontaggen stämmer med den du hittade i metattaggen på sidan. De andra söksvaren har en beskrivningstagg som är relaterad till Wikipedia sidans språk.
