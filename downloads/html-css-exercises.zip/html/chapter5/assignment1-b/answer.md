# Block element
Det <section> elementet har inget innehåll och syns därför inte alls. Genom att lägga till exempel lite text i det får man det att synas. Radbrytningar i html saknar betydelse för utseendet. 
